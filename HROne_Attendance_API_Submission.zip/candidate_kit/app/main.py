"""Employee Attendance & Analytics API (HROne contract v2.0)."""
from __future__ import annotations

import os
import re
import logging
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP
from typing import Literal, Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, ConfigDict, Field, StrictInt, field_validator, model_validator
from pymongo import ASCENDING, DESCENDING, MongoClient, ReturnDocument
from pymongo.errors import DuplicateKeyError, PyMongoError
from bson import ObjectId

load_dotenv()
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
MONGO_DB = os.getenv("MONGO_DB", "attendance_db")
client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=3000, tz_aware=False)
db = client[MONGO_DB]
IST = timezone(timedelta(hours=5, minutes=30))
UTC = timezone.utc
PRESENCE = ("PRESENT", "WFH", "ON_DUTY")
STATUSES = (*PRESENCE, "ABSENT", "LEAVE")
MONTH_RE = re.compile(r"^\d{4}-(0[1-9]|1[0-2])$")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
TIME_RE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")

app = FastAPI(title="Employee Attendance & Analytics API", version="2.0.0")


@app.on_event("startup")
def ensure_indexes() -> None:
    # Unique indexes are the concurrency guarantees, not just query optimizations.
    # Do not prevent the process from starting if MongoDB is temporarily down;
    # /health reports 503 and a restart will retry index creation.
    try:
        db.employees.create_index([("emp_code", ASCENDING)], unique=True, name="uq_employee_code")
        db.employees.create_index([("department", ASCENDING), ("emp_code", ASCENDING)], name="ix_employee_department_code")
        db.employees.create_index([("department", ASCENDING), ("joined_on", ASCENDING)], name="ix_employee_department_joined")
        db.employees.create_index([("joined_on", ASCENDING)], name="ix_employee_joined_on")
        db.attendance_logs.create_index([("emp_code", ASCENDING), ("date", ASCENDING)], unique=True, name="uq_attendance_employee_date")
        db.attendance_logs.create_index([("date", DESCENDING), ("emp_code", ASCENDING)], name="ix_attendance_date_employee")
        db.attendance_logs.create_index([("emp_code", ASCENDING), ("date", ASCENDING), ("status", ASCENDING)], name="ix_attendance_employee_date_status")
        db.attendance_logs.create_index([("punch_in", DESCENDING)], name="ix_attendance_punch_in")
    except PyMongoError:
        logging.exception("Could not create MongoDB indexes during startup")


# ---------- validation / time / serialization helpers ----------
def parse_date(value: str, field: str = "date") -> date:
    if not isinstance(value, str) or not DATE_RE.fullmatch(value):
        raise HTTPException(422, f"{field} must be YYYY-MM-DD")
    try:
        return date.fromisoformat(value)
    except ValueError:
        raise HTTPException(422, f"{field} must be a valid calendar date")


def parse_month(value: str) -> tuple[date, date]:
    if not MONTH_RE.fullmatch(value or ""):
        raise HTTPException(422, "month must be YYYY-MM")
    y, m = map(int, value.split("-"))
    try:
        start = date(y, m, 1)
        end = date(y + (m == 12), 1 if m == 12 else m + 1, 1) - timedelta(days=1)
    except ValueError:
        raise HTTPException(422, "month must be a valid calendar month")
    return start, end


def millis_to_dt(value: int) -> datetime:
    # StrictInt prevents floats/strings; enforce contract's epoch-ms range.
    if isinstance(value, bool) or not isinstance(value, int) or not 100_000_000_000 <= value <= 4_102_444_800_000:
        raise HTTPException(422, "timestamp must be epoch milliseconds")
    return datetime.fromtimestamp(value / 1000, UTC).replace(microsecond=0, tzinfo=None)


def dt_to_millis(value: Optional[datetime]) -> Optional[int]:
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=UTC)
    return int(value.timestamp() * 1000)


def now_utc_naive() -> datetime:
    return datetime.now(UTC).replace(microsecond=0, tzinfo=None)


def local_dt(value: datetime) -> datetime:
    # PyMongo's naive datetimes are UTC by contract.
    if value.tzinfo is None:
        value = value.replace(tzinfo=UTC)
    return value.astimezone(IST)


def attendance_date(punch_in: datetime, shift_start: str, shift_end: str) -> str:
    local = local_dt(punch_in)
    # For overnight shifts, an early-morning punch belongs to the prior shift-start date.
    if shift_end <= shift_start and local.strftime("%H:%M") < shift_end:
        local -= timedelta(days=1)
    return local.date().isoformat()


def shift_start_for_date(record_date: str, employee: dict) -> datetime:
    d = parse_date(record_date)
    h, m = map(int, employee["shift_start"].split(":"))
    return datetime.combine(d, time(h, m), IST).astimezone(UTC).replace(tzinfo=None)


def shift_end_for_record(record_date: str, employee: dict, punch_in: Optional[datetime] = None) -> datetime:
    d = parse_date(record_date)
    start = employee["shift_start"]
    end = employee["shift_end"]
    eh, em = map(int, end.split(":"))
    end_date = d
    if end <= start:
        end_date += timedelta(days=1)
    # In an overnight shift, record date is the shift-start date even if punch-in was after midnight.
    return datetime.combine(end_date, time(eh, em), IST).astimezone(UTC).replace(tzinfo=None)


def late_minutes(punch_in: Optional[datetime], record_date: str, employee: dict, status: str) -> int:
    if punch_in is None or status not in PRESENCE:
        return 0
    local = local_dt(punch_in)
    # Shift start is on the record date (IST); overnight early punches are handled by attendance_date.
    start = shift_start_for_date(record_date, employee)
    seconds = int((punch_in - start).total_seconds())
    return seconds // 60 if seconds > 600 else 0


def work_hours(punch_in: Optional[datetime], punch_out: Optional[datetime]) -> Optional[float]:
    if punch_in is None or punch_out is None:
        return None
    seconds = int((punch_out - punch_in).total_seconds())
    return float((Decimal(seconds) / Decimal(3600)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def overtime_minutes(punch_out: Optional[datetime], record_date: str, employee: dict, status: str) -> int:
    if punch_out is None or status not in PRESENCE:
        return 0
    end = shift_end_for_record(record_date, employee)
    seconds = int((punch_out - end).total_seconds())
    minutes = seconds // 60
    return minutes if minutes >= 30 else 0


def recompute(doc: dict, employee: dict) -> dict:
    status = doc.get("status", "PRESENT")
    pin = doc.get("punch_in")
    pout = doc.get("punch_out")
    if status not in PRESENCE:
        doc["punch_in"] = doc["punch_out"] = None
        pin = pout = None
    doc["late_minutes"] = late_minutes(pin, doc["date"], employee, status)
    doc["work_hours"] = work_hours(pin, pout)
    doc["overtime_minutes"] = overtime_minutes(pout, doc["date"], employee, status)
    doc["half_day"] = doc["work_hours"] is not None and doc["work_hours"] < 4.5
    doc.setdefault("history", [])
    return doc


def round_num(value, places=2):
    if value is None:
        return None
    quantum = Decimal("1").scaleb(-places)
    return float(Decimal(str(value)).quantize(quantum, rounding=ROUND_HALF_UP))


def record_out(doc: dict) -> dict:
    result = {k: v for k, v in doc.items() if k != "_id"}
    for key in ("punch_in", "punch_out"):
        result[key] = dt_to_millis(result.get(key))
    result["history"] = result.get("history") or []
    for entry in result["history"]:
        entry["at"] = dt_to_millis(entry.get("at"))
        for change in entry.get("changes", {}).values():
            for side in ("from", "to"):
                if isinstance(change.get(side), datetime):
                    change[side] = dt_to_millis(change[side])
    result.setdefault("late_minutes", 0)
    result.setdefault("overtime_minutes", 0)
    result.setdefault("half_day", False)
    result.setdefault("work_hours", None)
    return result


def valid_page(page: int, page_size: int) -> None:
    if page < 1 or not 1 <= page_size <= 100:
        raise HTTPException(422, "page must be >= 1 and page_size must be between 1 and 100")


def working_days(start: date, end: date) -> int:
    if end < start:
        return 0
    weeks, rem = divmod((end - start).days + 1, 7)
    count = weeks * 5
    for i in range(rem):
        if (start + timedelta(days=weeks * 7 + i)).weekday() < 5:
            count += 1
    return count


def mongo_round(expr, places=2):
    # Positive-value ROUND_HALF_UP (MongoDB $round itself uses ties-to-even).
    factor = 10 ** places
    return {"$divide": [{"$floor": {"$add": [{"$multiply": [expr, factor]}, 0.5]}}, factor]}


def attendance_match_pipeline(month_start: str, month_end: str, emp_code: Optional[str] = None):
    match = {"date": {"$gte": month_start, "$lte": month_end}}
    if emp_code:
        match["emp_code"] = emp_code
    return [{"$match": match}]


def json_safe(value):
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, list):
        return [json_safe(v) for v in value]
    if isinstance(value, ObjectId):
        return str(value)
    if isinstance(value, datetime):
        return dt_to_millis(value)
    return value


# ---------- request models ----------
class EmployeeIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    emp_code: str = Field(pattern=r"^EMP\d{4,6}$")
    name: str = Field(min_length=1, max_length=100)
    email: str = Field(max_length=120, pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
    department: str = Field(min_length=1, max_length=50)
    shift_start: str = Field(default="09:30", pattern=r"^([01]\d|2[0-3]):[0-5]\d$")
    shift_end: str = Field(default="18:30", pattern=r"^([01]\d|2[0-3]):[0-5]\d$")
    joined_on: str

    @field_validator("joined_on")
    @classmethod
    def valid_joined_on(cls, v):
        parse_date(v, "joined_on")
        return v

    @model_validator(mode="after")
    def different_shifts(self):
        if self.shift_start == self.shift_end:
            raise ValueError("shift_start must differ from shift_end")
        return self


class PunchInIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    emp_code: str
    punched_at: Optional[StrictInt] = None
    status: Literal["PRESENT", "WFH", "ON_DUTY"] = "PRESENT"

    @field_validator("punched_at")
    @classmethod
    def valid_timestamp(cls, v):
        if v is not None and not 100_000_000_000 <= v <= 4_102_444_800_000:
            raise ValueError("punched_at must be epoch milliseconds")
        return v


class PunchOutIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    emp_code: str
    punched_at: Optional[StrictInt] = None

    @field_validator("punched_at")
    @classmethod
    def valid_timestamp(cls, v):
        if v is not None and not 100_000_000_000 <= v <= 4_102_444_800_000:
            raise ValueError("punched_at must be epoch milliseconds")
        return v


class RegularizeIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    status: Optional[Literal["PRESENT", "ABSENT", "LEAVE", "WFH", "ON_DUTY"]] = None
    punch_in: Optional[StrictInt] = None
    punch_out: Optional[StrictInt] = None
    reason: str = Field(min_length=5, max_length=200)
    regularized_by: str = Field(min_length=1, max_length=50)

    @field_validator("punch_in", "punch_out")
    @classmethod
    def valid_timestamp(cls, v):
        if v is not None and not 100_000_000_000 <= v <= 4_102_444_800_000:
            raise ValueError("timestamps must be epoch milliseconds")
        return v


# ---------- common aggregation expressions ----------
def is_weekday_date_expr(field="date"):
    return {"$and": [{"$gte": [{"$dayOfWeek": {"$dateFromString": {"dateString": f"${field}"}}}, 2]}, {"$lte": [{"$dayOfWeek": {"$dateFromString": {"dateString": f"${field}"}}}, 6]}]}


def present_fraction_expr(doc_prefix="$"):
    # Fractional contribution: a completed half-day contributes 0.5.
    return {"$cond": [
        {"$in": [f"{doc_prefix}status", list(PRESENCE)]},
        {"$cond": [{"$eq": [f"{doc_prefix}half_day", True]}, 0.5, 1]}, 0
    ]}


# ---------- endpoints ----------
@app.get("/health")
def health():
    try:
        db.command("ping")
        return {"status": "ok"}
    except PyMongoError:
        raise HTTPException(503, "MongoDB unavailable")


@app.post("/employees", status_code=201)
def create_employee(body: EmployeeIn):
    doc = body.model_dump()
    doc["created_at"] = now_utc_naive()
    try:
        db.employees.insert_one(doc)
    except DuplicateKeyError:
        raise HTTPException(409, "emp_code already exists")
    return {**{k: v for k, v in doc.items() if k != "created_at"}, "created_at": dt_to_millis(doc["created_at"])}


@app.get("/employees")
def list_employees(department: Optional[str] = None, page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100)):
    valid_page(page, page_size)
    q = {"department": department} if department is not None else {}
    total = db.employees.count_documents(q)
    docs = list(db.employees.find(q, {"_id": 0}).sort("emp_code", ASCENDING).skip((page - 1) * page_size).limit(page_size))
    for d in docs:
        d["created_at"] = dt_to_millis(d.get("created_at"))
    return {"items": docs, "total": total, "page": page, "page_size": page_size}


@app.post("/attendance/punch-in", status_code=201)
def punch_in(body: PunchInIn):
    emp = db.employees.find_one({"emp_code": body.emp_code}, {"_id": 0})
    if not emp:
        raise HTTPException(404, "employee not found")
    ts = millis_to_dt(body.punched_at) if body.punched_at is not None else now_utc_naive()
    d = attendance_date(ts, emp["shift_start"], emp["shift_end"])
    doc = {
        "emp_code": body.emp_code, "date": d, "status": body.status,
        "punch_in": ts, "punch_out": None, "work_hours": None,
        "late_minutes": late_minutes(ts, d, emp, body.status), "overtime_minutes": 0,
        "half_day": False, "history": []
    }
    try:
        db.attendance_logs.insert_one(doc)
    except DuplicateKeyError:
        raise HTTPException(409, "already punched in for this date")
    return record_out(doc)


@app.post("/attendance/punch-out")
def punch_out(body: PunchOutIn):
    emp = db.employees.find_one({"emp_code": body.emp_code}, {"_id": 0})
    if not emp:
        raise HTTPException(404, "employee not found")
    ts = millis_to_dt(body.punched_at) if body.punched_at is not None else now_utc_naive()
    # Most recent open record no later than this punch-out; supports overnight shifts.
    rec = db.attendance_logs.find_one({"emp_code": body.emp_code, "punch_in": {"$lte": ts}, "punch_out": None, "status": {"$in": list(PRESENCE)}}, sort=[("punch_in", DESCENDING)])
    if rec is None:
        already = db.attendance_logs.find_one({"emp_code": body.emp_code, "punch_in": {"$lte": ts}, "punch_out": {"$ne": None}, "status": {"$in": list(PRESENCE)}}, sort=[("punch_in", DESCENDING)])
        if already:
            raise HTTPException(409, "record already punched out")
        raise HTTPException(404, "no punch-in found")
    if ts <= rec["punch_in"] or ts - rec["punch_in"] > timedelta(hours=24):
        raise HTTPException(422, "punched_at must be after punch-in and within 24 hours")
    updated = db.attendance_logs.find_one_and_update(
        {"_id": rec["_id"], "punch_out": None},
        {"$set": {"punch_out": ts}}, return_document=ReturnDocument.AFTER)
    if updated is None:
        raise HTTPException(409, "record already punched out")
    updated = recompute(updated, emp)
    db.attendance_logs.update_one({"_id": updated["_id"], "punch_out": ts}, {"$set": {"work_hours": updated["work_hours"], "overtime_minutes": updated["overtime_minutes"], "half_day": updated["half_day"]}})
    return record_out(updated)


@app.get("/attendance")
def list_attendance(
    emp_code: Optional[str] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    status: Optional[Literal["PRESENT", "ABSENT", "LEAVE", "WFH", "ON_DUTY"]] = None,
    page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100),
):
    valid_page(page, page_size)
    if date_from:
        parse_date(date_from, "date_from")
    if date_to:
        parse_date(date_to, "date_to")
    if date_from and date_to and date_from > date_to:
        raise HTTPException(422, "date_from must be <= date_to")
    q = {}
    if emp_code:
        q["emp_code"] = emp_code
    if date_from or date_to:
        q["date"] = {}
        if date_from: q["date"]["$gte"] = date_from
        if date_to: q["date"]["$lte"] = date_to
    if status: q["status"] = status
    total = db.attendance_logs.count_documents(q)
    docs = list(db.attendance_logs.find(q, {"_id": 0}).sort([("date", DESCENDING), ("emp_code", ASCENDING)]).skip((page - 1) * page_size).limit(page_size))
    return {"items": [record_out(d) for d in docs], "total": total, "page": page, "page_size": page_size}


@app.patch("/attendance/{emp_code}/{date}")
def regularize_attendance(emp_code: str, date: str, body: RegularizeIn):
    parse_date(date)
    emp = db.employees.find_one({"emp_code": emp_code}, {"_id": 0})
    if not emp:
        raise HTTPException(404, "employee not found")
    rec = db.attendance_logs.find_one({"emp_code": emp_code, "date": date})
    if not rec:
        raise HTTPException(404, "attendance record not found")
    changes_in = body.model_dump(exclude={"reason", "regularized_by"}, exclude_unset=True)
    # Explicit nulls are not valid timestamp updates under the API contract.
    for key in ("punch_in", "punch_out"):
        if key in changes_in and changes_in[key] is None:
            raise HTTPException(422, f"{key} cannot be null")
    before = dict(rec)
    # Legacy documents may omit fields whose contract defaults are zero/false/empty.
    before.setdefault("late_minutes", 0)
    before.setdefault("overtime_minutes", 0)
    before.setdefault("half_day", False)
    before.setdefault("history", [])
    final = dict(before)
    for key, value in changes_in.items():
        final[key] = millis_to_dt(value) if key in ("punch_in", "punch_out") else value
    final.setdefault("history", [])
    status = final.get("status", "PRESENT")
    if status in ("ABSENT", "LEAVE"):
        if "punch_in" in changes_in or "punch_out" in changes_in:
            raise HTTPException(422, "ABSENT/LEAVE cannot be supplied with punch times")
        final["punch_in"] = final["punch_out"] = None
    elif final.get("punch_in") is None:
        raise HTTPException(422, "presence status requires punch_in")
    if final.get("punch_in") is not None:
        if attendance_date(final["punch_in"], emp["shift_start"], emp["shift_end"]) != date:
            raise HTTPException(422, "punch_in must belong to the record attendance date")
    if final.get("punch_out") is not None:
        if final.get("punch_in") is None or final["punch_out"] <= final["punch_in"] or final["punch_out"] - final["punch_in"] > timedelta(hours=24):
            raise HTTPException(422, "punch_out must be after punch_in and within 24 hours")
    final = recompute(final, emp)
    fields = ("status", "punch_in", "punch_out", "work_hours", "late_minutes", "overtime_minutes", "half_day")
    changes = {}
    for key in fields:
        old = before.get(key)
        new = final.get(key)
        if old != new:
            changes[key] = {"from": old, "to": new}
    if not changes:
        raise HTTPException(422, "request does not change the record")
    entry = {"at": now_utc_naive(), "by": body.regularized_by, "reason": body.reason, "changes": changes}
    # Compare-and-swap on the old history length and values prevents lost concurrent updates.
    history = rec.get("history", [])
    query = {"_id": rec["_id"]}
    if "history" in rec:
        query["history"] = history
    else:
        query["history"] = {"$exists": False}
    for key in fields:
        if key in rec:
            query[key] = rec[key]
        else:
            query[key] = {"$exists": False}
    update_fields = {k: final.get(k) for k in fields}
    updated = db.attendance_logs.find_one_and_update(query, {"$set": update_fields, "$push": {"history": entry}}, return_document=ReturnDocument.AFTER)
    if updated is None:
        raise HTTPException(409, "record changed concurrently; retry regularization")
    return record_out(updated)


@app.get("/analytics/employees/{emp_code}/monthly")
def employee_monthly(emp_code: str, month: str):
    start, end = parse_month(month)
    if not db.employees.find_one({"emp_code": emp_code}, {"_id": 1}):
        raise HTTPException(404, "employee not found")
    start_s, end_s = start.isoformat(), end.isoformat()
    # The employee is the aggregation root so working days are calculated in MongoDB too.
    pipeline = [
        {"$match": {"emp_code": emp_code}},
        {"$lookup": {"from": "attendance_logs", "let": {"code": "$emp_code"}, "pipeline": [
            {"$match": {"$expr": {"$and": [{"$eq": ["$emp_code", "$$code"]}, {"$gte": ["$date", start_s]}, {"$lte": ["$date", end_s]}]}}}
        ], "as": "logs"}},
        {"$set": {"working_start": {"$cond": [{"$gt": ["$joined_on", start_s]}, "$joined_on", start_s]}}},
        {"$set": {"working_days": {"$size": {"$filter": {"input": {"$map": {
            "input": {"$range": [0, {"$max": [0, {"$add": [{"$dateDiff": {"startDate": {"$dateFromString": {"dateString": "$working_start"}}, "endDate": {"$dateFromString": {"dateString": end_s}}, "unit": "day"}}, 1]}]}]},
            "as": "offset", "in": {"$dateAdd": {"startDate": {"$dateFromString": {"dateString": "$working_start"}}, "unit": "day", "amount": "$$offset"}}
        }}, "as": "day", "cond": {"$and": [{"$gte": [{"$dayOfWeek": "$$day"}, 2]}, {"$lte": [{"$dayOfWeek": "$$day"}, 6]}]}}}}}},
        {"$unwind": {"path": "$logs", "preserveNullAndEmptyArrays": True}},
        {"$group": {"_id": "$emp_code", "working_days": {"$first": "$working_days"},
            "present_days": {"$sum": {"$cond": [{"$and": [{"$in": ["$logs.status", list(PRESENCE)]}, {"$and": [{"$gte": [{"$dayOfWeek": {"$dateFromString": {"dateString": {"$ifNull": ["$logs.date", "1970-01-01"]}}}}, 2]}, {"$lte": [{"$dayOfWeek": {"$dateFromString": {"dateString": {"$ifNull": ["$logs.date", "1970-01-01"]}}}}, 6]}]}]}, {"$cond": [{"$eq": ["$logs.half_day", True]}, 0.5, 1]}, 0]}},
            "leave_days": {"$sum": {"$cond": [{"$eq": ["$logs.status", "LEAVE"]}, 1, 0]}},
            "late_count": {"$sum": {"$cond": [{"$gt": [{"$ifNull": ["$logs.late_minutes", 0]}, 0]}, 1, 0]}},
            "total_late_minutes": {"$sum": {"$ifNull": ["$logs.late_minutes", 0]}},
            "total_overtime_minutes": {"$sum": {"$ifNull": ["$logs.overtime_minutes", 0]}}
        }},
        {"$project": {"_id": 0, "emp_code": "$_id", "month": {"$literal": month}, "working_days": 1,
            "present_days": {"$round": ["$present_days", 2]}, "leave_days": 1, "late_count": 1,
            "total_late_minutes": 1, "total_overtime_minutes": 1,
            "attendance_pct": {"$cond": [{"$gt": ["$working_days", 0]}, mongo_round({"$multiply": [{"$divide": ["$present_days", "$working_days"]}, 100]}, 2), None]}}
        }
    ]
    result = list(db.employees.aggregate(pipeline, allowDiskUse=True))
    if not result:
        raise HTTPException(404, "employee not found")
    return result[0]


@app.get("/analytics/departments/summary")
def department_summary(month: str, department: Optional[str] = None):
    start, end = parse_month(month)
    start_s, end_s = start.isoformat(), end.isoformat()
    employee_match = {"joined_on": {"$lte": end_s}}
    if department is not None: employee_match["department"] = department
    pipeline = [
        {"$match": employee_match},
        {"$lookup": {"from": "attendance_logs", "let": {"code": "$emp_code"}, "pipeline": [
            {"$match": {"$expr": {"$and": [{"$eq": ["$emp_code", "$$code"]}, {"$gte": ["$date", start_s]}, {"$lte": ["$date", end_s]}]}}}
        ], "as": "logs"}},
        {"$addFields": {"eligible_days_start": {"$cond": [{"$gt": ["$joined_on", start_s]}, "$joined_on", start_s]}}},
        {"$addFields": {"employee_present_days": {"$sum": {"$map": {
            "input": "$logs", "as": "l",
            "in": {"$cond": [
                {"$and": [{"$in": ["$$l.status", list(PRESENCE)]}, {"$and": [{"$gte": [{"$dayOfWeek": {"$dateFromString": {"dateString": "$$l.date"}}}, 2]}, {"$lte": [{"$dayOfWeek": {"$dateFromString": {"dateString": "$$l.date"}}}, 6]}]}]},
                {"$cond": [{"$eq": ["$$l.half_day", True]}, 0.5, 1]}, 0
            ]}
        }}}}},
        {"$unwind": {"path": "$logs", "preserveNullAndEmptyArrays": True}},
        {"$group": {"_id": {"department": "$department", "emp_code": "$emp_code"},
            "employee_present_days": {"$first": "$employee_present_days"},
            "log_work_hours": {"$sum": {"$cond": [{"$and": [{"$in": ["$logs.status", list(PRESENCE)]}, {"$ne": ["$logs.work_hours", None]}]}, "$logs.work_hours", 0]}},
            "work_hours_count": {"$sum": {"$cond": [{"$and": [{"$in": ["$logs.status", list(PRESENCE)]}, {"$ne": ["$logs.work_hours", None]}]}, 1, 0]}},
            "late_count": {"$sum": {"$cond": [{"$gt": [{"$ifNull": ["$logs.late_minutes", 0]}, 0]}, 1, 0]}},
            "total_late_minutes": {"$sum": {"$ifNull": ["$logs.late_minutes", 0]}},
            "leave_count": {"$sum": {"$cond": [{"$eq": ["$logs.status", "LEAVE"]}, 1, 0]}},
            "on_duty_count": {"$sum": {"$cond": [{"$eq": ["$logs.status", "ON_DUTY"]}, 1, 0]}}
        }},
        {"$group": {"_id": "$_id.department", "headcount": {"$sum": 1}, "present_days": {"$sum": "$employee_present_days"},
            "hours_sum": {"$sum": "$log_work_hours"}, "hours_count": {"$sum": "$work_hours_count"},
            "late_count": {"$sum": "$late_count"}, "total_late_minutes": {"$sum": "$total_late_minutes"}, "leave_count": {"$sum": "$leave_count"}, "on_duty_count": {"$sum": "$on_duty_count"}}},
        {"$project": {"_id": 0, "department": "$_id", "headcount": 1, "present_days": {"$round": ["$present_days", 2]}, "avg_work_hours": {"$cond": [{"$gt": ["$hours_count", 0]}, mongo_round({"$divide": ["$hours_sum", "$hours_count"]}, 2), None]}, "late_count": 1, "total_late_minutes": 1, "leave_count": 1, "on_duty_count": 1}},
        {"$sort": {"department": 1}}
    ]
    items = list(db.employees.aggregate(pipeline, allowDiskUse=True))
    return {"month": month, "items": items}


@app.get("/analytics/leaderboard/late")
def late_leaderboard(month: str, limit: int = Query(10, ge=1, le=50), department: Optional[str] = None):
    start, end = parse_month(month)
    pipeline = [
        {"$match": {"date": {"$gte": start.isoformat(), "$lte": end.isoformat()}}},
        {"$group": {"_id": "$emp_code", "total_late_minutes": {"$sum": {"$ifNull": ["$late_minutes", 0]}}, "late_count": {"$sum": {"$cond": [{"$gt": [{"$ifNull": ["$late_minutes", 0]}, 0]}, 1, 0]}}}},
        {"$match": {"total_late_minutes": {"$gt": 0}}},
        {"$lookup": {"from": "employees", "localField": "_id", "foreignField": "emp_code", "as": "employee"}},
        {"$unwind": "$employee"},
    ]
    if department is not None:
        pipeline.append({"$match": {"employee.department": department}})
    pipeline += [
        {"$setWindowFields": {"sortBy": {"total_late_minutes": -1}, "output": {"rank": {"$rank": {}}}}},
        {"$match": {"rank": {"$lte": limit}}},
        {"$sort": {"total_late_minutes": -1, "_id": 1}},
        {"$project": {"_id": 0, "rank": 1, "emp_code": "$_id", "name": "$employee.name", "department": "$employee.department", "total_late_minutes": 1, "late_count": 1}}
    ]
    items = list(db.attendance_logs.aggregate(pipeline, allowDiskUse=True))
    return {"month": month, "items": items}


@app.get("/analytics/departments/{department}/trend")
def department_trend(department: str, from_date: str = Query(..., alias="from"), to_date: str = Query(..., alias="to")):
    start, end = parse_date(from_date, "from"), parse_date(to_date, "to")
    if end < start:
        raise HTTPException(422, "to must be on or after from")
    if (end - start).days + 1 > 92:
        raise HTTPException(422, "date range cannot exceed 92 days")
    if not db.employees.find_one({"department": department}, {"_id": 1}):
        raise HTTPException(404, "department not found")
    # Build a bounded date spine in MongoDB, then calculate daily counts and moving average there.
    date_expr = {"$dateToString": {"date": {"$dateAdd": {"startDate": {"$dateFromString": {"dateString": from_date}}, "unit": "day", "amount": "$$offset"}}, "format": "%Y-%m-%d"}}
    daily_present = {"$sum": {"$map": {"input": "$day_logs", "as": "l", "in": {"$cond": [{"$in": ["$$l.status", list(PRESENCE)]}, {"$cond": [{"$eq": ["$$l.half_day", True]}, 0.5, 1]}, 0]}}}}
    daily_late = {"$size": {"$filter": {"input": "$day_logs", "as": "l", "cond": {"$gt": [{"$ifNull": ["$$l.late_minutes", 0]}, 0]}}}}
    pipeline = [
        {"$match": {"department": department}},
        {"$lookup": {"from": "attendance_logs", "let": {"code": "$emp_code"}, "pipeline": [
            {"$match": {"$expr": {"$and": [{"$eq": ["$emp_code", "$$code"]}, {"$gte": ["$date", from_date]}, {"$lte": ["$date", to_date]}]}}},
            {"$project": {"_id": 0, "date": 1, "status": 1, "late_minutes": 1, "half_day": 1}}
        ], "as": "logs"}},
        {"$group": {"_id": None, "employees": {"$push": {"emp_code": "$emp_code", "joined_on": "$joined_on", "logs": "$logs"}}}},
        {"$project": {"_id": 0, "employees": 1, "dates": {"$map": {"input": {"$range": [0, (end - start).days + 1]}, "as": "offset", "in": date_expr}}}},
        {"$unwind": "$dates"},
        {"$set": {"date": "$dates", "day_date": {"$dateFromString": {"dateString": "$dates"}}}},
        {"$set": {"day_employees": {"$filter": {"input": "$employees", "as": "e", "cond": {"$lte": ["$$e.joined_on", "$date"]}}}}},
        {"$set": {"headcount": {"$size": "$day_employees"}, "day_logs": {"$reduce": {"input": "$day_employees", "initialValue": [], "in": {"$concatArrays": ["$$value", "$$this.logs"]}}}}},
        {"$set": {"day_logs": {"$filter": {"input": "$day_logs", "as": "l", "cond": {"$eq": ["$$l.date", "$date"]}}}}},
        {"$set": {"present_count": daily_present, "late_count": daily_late, "is_working_day": {"$and": [{"$gte": [{"$dayOfWeek": "$day_date"}, 2]}, {"$lte": [{"$dayOfWeek": "$day_date"}, 6]}]}}},
        {"$set": {"attendance_rate": {"$cond": [{"$and": ["$is_working_day", {"$gt": ["$headcount", 0]}]}, mongo_round({"$divide": ["$present_count", "$headcount"]}, 4), None]}}},
        {"$setWindowFields": {"sortBy": {"date": 1}, "output": {"moving_avg_7d": {"$avg": "$attendance_rate", "window": {"documents": [-6, 0]}}}}},
        {"$project": {"_id": 0, "date": 1, "is_working_day": 1, "headcount": 1, "present_count": 1, "late_count": 1, "attendance_rate": 1, "moving_avg_7d": {"$cond": [{"$eq": [{"$type": "$moving_avg_7d"}, "missing"]}, None, {"$round": ["$moving_avg_7d", 4]}]}}},
        {"$sort": {"date": 1}}
    ]
    items = list(db.employees.aggregate(pipeline, allowDiskUse=True))
    # Avoid driver-specific null/missing values in the JSON contract.
    for item in items:
        if item.get("moving_avg_7d") is not None:
            item["moving_avg_7d"] = round_num(item["moving_avg_7d"], 4)
        if item.get("attendance_rate") is not None:
            item["attendance_rate"] = round_num(item["attendance_rate"], 4)
    return {"department": department, "items": items}


@app.get("/admin/explain/{endpoint}")
def explain_endpoint(
    endpoint: Literal["attendance_list", "employee_monthly", "department_summary", "late_leaderboard", "department_trend"],
    emp_code: Optional[str] = None, month: Optional[str] = None, department: Optional[str] = None,
    limit: int = Query(10, ge=1, le=50), date_from: Optional[str] = None, date_to: Optional[str] = None,
    status: Optional[Literal["PRESENT", "ABSENT", "LEAVE", "WFH", "ON_DUTY"]] = None,
    from_date: Optional[str] = Query(None, alias="from"), to_date: Optional[str] = Query(None, alias="to"),
    page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100),
):
    valid_page(page, page_size)
    if endpoint == "attendance_list":
        q = {}
        if emp_code: q["emp_code"] = emp_code
        if date_from: parse_date(date_from, "date_from"); q.setdefault("date", {})["$gte"] = date_from
        if date_to: parse_date(date_to, "date_to"); q.setdefault("date", {})["$lte"] = date_to
        if date_from and date_to and date_from > date_to: raise HTTPException(422, "date_from must be <= date_to")
        if status: q["status"] = status
        explain = db.command("explain", {"find": "attendance_logs", "filter": q, "sort": {"date": -1, "emp_code": 1}, "skip": (page - 1) * page_size, "limit": page_size}, verbosity="executionStats")
        return {"endpoint": endpoint, "collection": "attendance_logs", "explain": json_safe(explain)}
    if not month:
        raise HTTPException(422, "month is required for this endpoint")
    start, end = parse_month(month)
    if endpoint == "employee_monthly":
        if not emp_code: raise HTTPException(422, "emp_code is required")
        pipeline = [{"$match": {"emp_code": emp_code, "date": {"$gte": start.isoformat(), "$lte": end.isoformat()}}}]
        explain = db.command("explain", {"aggregate": "attendance_logs", "pipeline": pipeline, "cursor": {}}, verbosity="executionStats")
        return {"endpoint": endpoint, "collection": "attendance_logs", "explain": json_safe(explain)}
    if endpoint == "department_summary":
        pipeline = [{"$match": {"joined_on": {"$lte": end.isoformat()}, **({"department": department} if department else {})}}, {"$lookup": {"from": "attendance_logs", "localField": "emp_code", "foreignField": "emp_code", "as": "logs"}}]
        explain = db.command("explain", {"aggregate": "employees", "pipeline": pipeline, "cursor": {}}, verbosity="executionStats")
        return {"endpoint": endpoint, "collection": "employees", "explain": json_safe(explain)}
    if endpoint == "late_leaderboard":
        pipeline = [{"$match": {"date": {"$gte": start.isoformat(), "$lte": end.isoformat()}}}, {"$group": {"_id": "$emp_code", "total_late_minutes": {"$sum": {"$ifNull": ["$late_minutes", 0]}}}}]
        explain = db.command("explain", {"aggregate": "attendance_logs", "pipeline": pipeline, "cursor": {}}, verbosity="executionStats")
        return {"endpoint": endpoint, "collection": "attendance_logs", "explain": json_safe(explain)}
    if endpoint == "department_trend":
        if not department or not from_date or not to_date: raise HTTPException(422, "department, from and to are required")
        start_date, end_date = parse_date(from_date, "from"), parse_date(to_date, "to")
        if end_date < start_date or (end_date - start_date).days + 1 > 92:
            raise HTTPException(422, "invalid trend date range")
        pipeline = [{"$match": {"department": department}}, {"$lookup": {"from": "attendance_logs", "localField": "emp_code", "foreignField": "emp_code", "as": "logs"}}]
        explain = db.command("explain", {"aggregate": "employees", "pipeline": pipeline, "cursor": {}}, verbosity="executionStats")
        return {"endpoint": endpoint, "collection": "employees", "explain": json_safe(explain)}
    raise HTTPException(422, "unsupported endpoint")
