"""Fast unit checks for deterministic business-rule helpers.

Run with: python -m unittest discover -s tests
"""
import unittest
from datetime import datetime, timezone

from app.main import late_minutes, work_hours, overtime_minutes, attendance_date, IST


class AttendanceRuleTests(unittest.TestCase):
    def test_late_grace_boundary_is_strict(self):
        employee = {"shift_start": "09:30", "shift_end": "18:30"}
        at_grace = datetime(2026, 1, 5, 4, 10, 0)  # 09:40 IST
        after_grace = datetime(2026, 1, 5, 4, 10, 1)
        self.assertEqual(late_minutes(at_grace, "2026-01-05", employee, "PRESENT"), 0)
        self.assertEqual(late_minutes(after_grace, "2026-01-05", employee, "PRESENT"), 10)

    def test_work_hours_are_half_up(self):
        start = datetime(2026, 1, 5, 0, 0, 0)
        end = datetime(2026, 1, 5, 4, 30, 18)  # 4.505 hours -> 4.51
        self.assertEqual(work_hours(start, end), 4.51)

    def test_overtime_requires_thirty_whole_minutes(self):
        employee = {"shift_start": "09:30", "shift_end": "18:30"}
        end_shift = datetime(2026, 1, 5, 13, 0, 0)  # 18:30 IST
        self.assertEqual(overtime_minutes(datetime(2026, 1, 5, 13, 29, 59), "2026-01-05", employee, "PRESENT"), 0)
        self.assertEqual(overtime_minutes(datetime(2026, 1, 5, 13, 30, 0), "2026-01-05", employee, "PRESENT"), 30)

    def test_overnight_early_punch_belongs_to_previous_shift_date(self):
        employee = {"shift_start": "22:00", "shift_end": "06:00"}
        early = datetime(2026, 1, 6, 0, 30, 0)  # 06:00 IST exactly
        before_end = datetime(2026, 1, 6, 0, 29, 0)
        self.assertEqual(attendance_date(before_end, employee["shift_start"], employee["shift_end"]), "2026-01-05")
        self.assertEqual(attendance_date(early, employee["shift_start"], employee["shift_end"]), "2026-01-06")


if __name__ == "__main__":
    unittest.main()
